"""
segment between two points.
"""
from geo.quadrant import Quadrant
from geo.point import Point


class Segment:
    """
    oriented segment between two points.

    for example:

    - create a new segment between two points:

        segment = Segment([point1, point2])

    - create a new segment from coordinates:

        segment = Segment([Point([1.0, 2.0]), Point([3.0, 4.0])])

    - compute intersection point with other segment:

        intersection = segment1.intersection_with(segment2)

    """
    def __init__(self, points):
        """
        create a segment from an array of two points.
        """
        self.endpoints = points

    def __eq__(self, other):
        return self.endpoints == other.endpoints

    def copy(self):
        """
        return duplicate of given segment (no shared points with original,
        they are also copied).
        """
        return Segment([p.copy() for p in self.endpoints])

    def length(self):
        """
        return length of segment.
        example:
            segment = Segment([Point([1, 1]), Point([5, 1])])
            distance = segment.length() # distance is 4
        """
        return self.endpoints[0].distance_to(self.endpoints[1])

    def bounding_quadrant(self):
        """
        return min quadrant containing self.
        """
        quadrant = Quadrant.empty_quadrant(2)
        for point in self.endpoints:
            quadrant.add_point(point)
        return quadrant

    def is_vertical(self):
        """
        return if we are a truely vertical segment.
        """
        return self.endpoints[0].coordinates[0] == self.endpoints[1].coordinates[0]

    def svg_content(self):
        """
        svg for tycat.
        """
        print('<line x1="{}" y1="{}" x2="{}" y2="{}" stroke="orange" fill="transparent" stroke-width="5"/>\n'.format(
            *self.endpoints[0].coordinates,
            *self.endpoints[1].coordinates))

    def endpoint_not(self, point):
        """
        return first endpoint which is not given point.
        """
        if self.endpoints[0] == point:
            return self.endpoints[1]

        return self.endpoints[0]

    def contains(self, possible_point):
        """
        is given point inside us ?
        be careful, determining if a point is inside a segment is a difficult problem
        (it is in fact a meaningless question in most cases).
        you might get wrong results for points extremely near endpoints.
        """

        distance = sum(possible_point.distance_to(p) for p in self.endpoints)
        return abs(distance - self.length()) < 0.000001

    def eq_droite(self):
        """
        Give the parameters of the straight line in which the segment is
        contained
        """
        if self.is_vertical():
            return None
        else:
            A, B = self.endpoints
            (xA, yA), (xB, yB) = A.coordinates, B.coordinates
            coeff = (yA - yB) / (xA - xB)
            ordonne_a_origine = yA - coeff*xA
            return coeff, ordonne_a_origine

    def intersection_with(self, other):
        """
        compute intersection point with other segment
        if there is no intersection return None
        """
        if self.is_vertical() and other.is_vertical():
            return None

        vertical = None
        not_vertical = None
        if self.is_vertical():
            vertical = self
            not_vertical = other
        elif other.is_vertical():
            vertical = other
            not_vertical = self

        if vertical is not None:
            coeff, oao = not_vertical.eq_droite()
            x_vertical = vertical.endpoints[0].coordinates[0]
            y_inter = coeff*x_vertical + oao
            yAv, yBv = vertical.endpoints[0].coordinates[1], vertical.endpoints[1].coordinates[1]
            if min(yAv, yBv) <= y_inter <= max(yAv, yBv):
                return Point([x_vertical, y_inter])
            return None

        else:
            coeff1, oao1 = self.eq_droite()
            coeff2, oao2 = other.eq_droite()
            if coeff1 == coeff2:
                return None
            x_inter = (oao1 - oao2) / (coeff2 - coeff1)
            y_inter = coeff2*x_inter + oao2
            xA1, xB1 = self.endpoints[0].coordinates[0], self.endpoints[1].coordinates[0]
            xA2, xB2 = other.endpoints[0].coordinates[0], other.endpoints[1].coordinates[0]
            if min(xA1, xB1) <= x_inter <= max(xA1, xB1) and min(xA2, xB2) <= x_inter <= max(xA2, xB2):
                return Point([x_inter, y_inter])
            return None


    def __str__(self):
        return "Segment([" + str(self.endpoints[0]) + ", " + \
            str(self.endpoints[1]) + "])"

    def __repr__(self):
        return "[" + repr(self.endpoints[0]) + ", " + \
            repr(self.endpoints[1]) + "])"

    def __hash__(self):
        return hash(tuple(self.endpoints))
