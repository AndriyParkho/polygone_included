#!/usr/bin/env python3
"""
génère des carrés dans le dossier mis en paramètre
Prends en paramètre des arguments de la forme : dossier type_de_fichier
SEUL LA PARTIE QUADRILLAGE EST COMMENTEE, LES AUTRES CHANGEANTS QUE TRES PEU
"""
import sys
from random import randint
from random import random
import os

def generer_carre_aleatoire(xmin, xmax, ymin, ymax):
    """
    genere un carre a l'interieur des limites
    pas tres utile mais généré un carré aléatoire avant, ce qui a été changé
    """

    bonnes_coordonnes = False
    while not bonnes_coordonnes:
        abscisses = [xmin+1, xmax-1]
        ordonnees = [ymin+1, ymax-1]
        x_min, y_min = min(abscisses), min(ordonnees)
        x_max, y_max = max(abscisses), max(ordonnees)
        if x_min != x_max and y_min != y_max :
            bonnes_coordonnes = True

    return [x_min, x_max, y_min, y_max]

def iterateur_points_carre(bornes_carres):
    """
    prend les bornes du carre et itere sur les 4 points
    """
    for indices in [[0, 2], [0, 3], [1, 3], [1, 2]]:
        yield (bornes_carres[indices[0]], bornes_carres[indices[1]])

def creation_fichiers_escalier(dossier, nombre_carre_max):
    """
    créer le fichier, remplace existant si existe deja
    Nombre de carre en puissance de 10
    """
    taille_grand_carre_max = 50
    bases = [5, 10, 25]
    for nombre_carre in range(0, nombre_carre_max):
        for nombre in bases:
            print("Creation de : ", str(dossier)+"/carres_"+str(nombre_carre)+".poly")
            fichier = open(str(dossier)+"/carres_"+str(nombre_carre)+".poly", "w")
            carres = [None]*nombre_carre
            for i in range(nombre_carre):
                if i==0 :
                    nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(0, taille_grand_carre_max, 0, taille_grand_carre_max))
                    x_grand_carre = 0
                    y_grand_carre = 0
                else:
                    nouveau_carre_dedans = random() < 1/2
                    x_min, y_min = carres[i-1][0]
                    x_max, y_max = carres[i-1][2]
                    if x_max - x_min < 2 or y_max - y_min < 2 :
                        nouveau_carre_dedans = False
                    if nouveau_carre_dedans :
                         nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x_min, x_max, y_min, y_max))
                    else:
                        choix = randint(0, 3)
                        if choix == 1:
                            x_grand_carre += taille_grand_carre_max
                            nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x_grand_carre, x_grand_carre + taille_grand_carre_max, y_min + 1, y_max + 1))
                        elif choix == 2:
                            y_grand_carre += taille_grand_carre_max
                            nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x_min+1, x_max+1, y_grand_carre, y_grand_carre + taille_grand_carre_max))
                        else:
                            x_grand_carre += taille_grand_carre_max
                            y_grand_carre += taille_grand_carre_max
                            nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x_grand_carre, x_grand_carre + taille_grand_carre_max,  y_grand_carre, y_grand_carre + taille_grand_carre_max))


                L_nouveau_carre = []
                for (x, y) in nouveau_carre :
                    fichier.write(str(i)+" "+str(x)+" "+str(y)+"\n")
                    L_nouveau_carre.append([x, y])
                carres[i] = (L_nouveau_carre)

            fichier.close()


def creation_fichiers_quadrillage(dossier, nombre_carre_max):
    """
    créer le fichier, remplace existant si existe deja
    Nombre de carre en puissance de 10
    """
    taille_grand_carre_max = 50 #taille des carrés
    for nombre_carre in range(0, nombre_carre_max+1, 1000) : #le nombre de carré qui va être généré dans les différents fichiers (le pas aurait du etre mis en argument pour un meilleur accès)
        taille_quadrillage = int(nombre_carre**0.5)*taille_grand_carre_max #largeur du quadrillage
        #---------------------GESTION DE FICHIER-----------------------
        print("Creation de : ", str(dossier)+"/carres_"+str(nombre_carre)+".poly")
        fichier = open(str(dossier)+"/carres_"+str(nombre_carre)+".poly", "w")
        #-----------------------INITIALISATION-------------------------
        x = 0
        y = 0
        i = 0
        carres = [None] * nombre_carre

        while i < nombre_carre:
            if x >= taille_quadrillage:
                x = 0
                y += taille_grand_carre_max

            if i == 0:
                #a l'initialisation, on est sûr de créer un carré
                nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x, x+taille_grand_carre_max, y, y+taille_grand_carre_max))
                x += taille_grand_carre_max
            else:
                #simulation d'une loi de Bernoulli de paramètre
                nouveau_carre_dedans = random() < 1/2

                #si les extremites du carré sont trop proche, on est sûr de mettre le carré dehors
                if x_max - x_min < 2 or y_max - y_min < 2 :
                    nouveau_carre_dedans = False

                if nouveau_carre_dedans :
                    x_min, y_min = carres[i-1][0]
                    x_max, y_max = carres[i-1][2]
                    #si il est dedans, on définit les limites comme les coordonnées du carré précèdent, et on le place à l'interieur
                    nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x_min, x_max, y_min, y_max))

                else:
                    #sinon, on continue le quadrillage
                    nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x, x+taille_grand_carre_max, y, y+taille_grand_carre_max))
                    x += taille_grand_carre_max

            #usage de mémoire supplémentaire, il suffisait juste de stocker le carré précèdent
            #on stacke toutes les coordonnées des carrés
            L_nouveau_carre = []
            for (x_carre, y_carre) in nouveau_carre :
                fichier.write(str(i)+" "+str(x_carre)+" "+str(y_carre)+"\n")
                L_nouveau_carre.append([x_carre, y_carre])
            carres[i] = (L_nouveau_carre)
            i+= 1

        fichier.close()


def creation_fichiers_imbriques(dossier, nombre_carre_max):
    """
    créer le fichier, remplace existant si existe deja
    Nombre de carre en puissance de 10
    """
    taille_grand_carre_max = 50
    taille_quadrillage = 20*taille_grand_carre_max
    bases = [5, 10, 25]
    for nombre_carre in range(0, nombre_carre_max+1, 40000):
        print("Creation de : ", str(dossier)+"/carres_"+str(nombre_carre)+".poly")
        fichier = open(str(dossier)+"/carres_"+str(nombre_carre)+".poly", "w")
        i = 0
        carres = [None] * nombre_carre
        while i < nombre_carre:
            if i == 0:
                nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(-1, 2, -1, 2))
            else:
                x_min, y_min = carres[i-1][0]
                x_max, y_max = carres[i-1][2]
                nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x_min -2, x_max+2, y_min-2, y_max+2))

            L_nouveau_carre = []
            for (x, y) in nouveau_carre :
                fichier.write(str(i)+" "+str(x)+" "+str(y)+"\n")
                L_nouveau_carre.append([x, y])
            carres[i] = (L_nouveau_carre)
            i += 1

        fichier.close()


def creation_fichiers_quadrillage_pas_dedans(dossier, nombre_polygones_max):
    """
    créer le fichier, remplace existant si existe deja
    Nombre de carre en puissance de 10
    """
    taille_grand_carre_max = 50
    bases = [5, 10, 25]
    for nombre_carre in range(0, nombre_polygones_max+1, 500):
        taille_quadrillage = int(nombre_carre**0.5)*taille_grand_carre_max
        print("Creation de : ", str(dossier)+"/carres_"+str(nombre_carre)+".poly")
        fichier = open(str(dossier)+"/carres_"+str(nombre_carre)+".poly", "w")
        x = 0
        y = 0
        i= 0
        carres = [None] * nombre_carre
        while i < nombre_carre:
            if x >= taille_quadrillage:
                x = 0
                y += taille_grand_carre_max
            if i == 0:
                nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x, x+taille_grand_carre_max, y, y+taille_grand_carre_max))
                x += taille_grand_carre_max
            else:
                x_min, y_min = carres[i-1][0]
                x_max, y_max = carres[i-1][2]
                nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x, x+taille_grand_carre_max, y, y+taille_grand_carre_max))
                x += taille_grand_carre_max


            L_nouveau_carre = []
            for (x_carre, y_carre) in nouveau_carre :
                fichier.write(str(i)+" "+str(x_carre)+" "+str(y_carre)+"\n")
                L_nouveau_carre.append([x_carre, y_carre])
            carres[i] = (L_nouveau_carre)
            i+= 1

        fichier.close()

def creation_fichiers_quadrillage_verticale(dossier, nombre_polygones_max):
    """
    créer le fichier, remplace existant si existe deja
    Nombre de carre en puissance de 10
    """
    taille_grand_carre_max = 50
    taille_quadrillage = 20*taille_grand_carre_max
    for nombre_carre in range(0, nombre_polygones_max+1, 50000):
        print("Creation de : ", str(dossier)+"/carres_"+str(nombre_carre)+".poly")
        fichier = open(str(dossier)+"/carres_"+str(nombre_carre)+".poly", "w")
        x_carre = 0
        y_carre = 0
        i= 0
        carres = [None] * nombre_carre
        while i < nombre_carre:
            nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x_carre, x_carre + taille_grand_carre_max+1, y_carre, y_carre + taille_grand_carre_max+1))
            y_carre += taille_grand_carre_max



            L_nouveau_carre = []
            for (x, y) in nouveau_carre :
                fichier.write(str(i)+" "+str(x)+" "+str(y)+"\n")
                L_nouveau_carre.append([x, y])
            carres[i] = (L_nouveau_carre)
            i+= 1

        fichier.close()

def creation_fichiers_quadrillage_horizontale(dossier, nombre_polygones_max):
    """
    créer le fichier, remplace existant si existe deja
    Nombre de carre en puissance de 10
    """
    taille_grand_carre_max = 50
    taille_quadrillage = 20*taille_grand_carre_max
    for nombre_carre in range(0, nombre_polygones_max+1, 100):
        print("Creation de : ", str(dossier)+"/carres_"+str(nombre_carre)+".poly")
        fichier = open(str(dossier)+"/carres_"+str(nombre_carre)+".poly", "w")
        x_carre = 0
        y_carre = 0
        i= 0
        carres = [None] * nombre_carre
        while i < nombre_carre:
            nouveau_carre = iterateur_points_carre(generer_carre_aleatoire(x_carre, x_carre + taille_grand_carre_max+1, y_carre, y_carre + taille_grand_carre_max+1))
            x_carre += taille_grand_carre_max



            L_nouveau_carre = []
            for (x, y) in nouveau_carre :
                fichier.write(str(i)+" "+str(x)+" "+str(y)+"\n")
                L_nouveau_carre.append([x, y])
            carres[i] = (L_nouveau_carre)
            i+= 1

        fichier.close()



def main():
    if len(sys.argv) == 1:
        print("Rentrez des paramètres de la forme : dossier type_de_polygones puissance")
        quit()
    else:
        dossier = sys.argv[1]
        if len(sys.argv) <= 2 or int(sys.argv[2]) > 4 or int(sys.argv[2]) == 0:
            creation_fichier = creation_fichiers_quadrillage
            print("Generation d'un quadrillage")
        elif int(sys.argv[2]) == 1:
            creation_fichier = creation_fichiers_imbriques
            print("Generation de carrés imbriqués")
        elif int(sys.argv[2])  == 2:
            creation_fichier = creation_fichiers_quadrillage_pas_dedans
            print("Generation de carrés avec aucune imbrication")
        elif int(sys.argv[2]) == 3:
            creation_fichier = creation_fichiers_quadrillage_verticale
        elif int(sys.argv[2]) == 4:
            creation_fichier = creation_fichiers_quadrillage_horizontale
        for fichier in os.listdir(dossier):
            os.remove(dossier +"/"+fichier)
        creation_fichier(dossier, 1000)


if __name__ == "__main__":
    main()
